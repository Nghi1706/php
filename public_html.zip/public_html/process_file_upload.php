<?php
// code PHP xử lý upload file
$upload_directory = __DIR__ . DIRECTORY_SEPARATOR . "picphp"; $upload_directory = __DIR__. DIRECTORY_SEPARATOR."picphp";
$local = $_FILES['file']['tmp_name'];
$name = $_FILES['file']['name'];
$name1=$upload_directory.'/'.$name;
move_uploaded_file($local,$name1);
header('location:https://petshop81.000webhostapp.com/themsanpham.php');
?>