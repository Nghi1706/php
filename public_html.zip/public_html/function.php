<?php
class detai{
	function ketnoi()
	{				
		$con=mysqli_connect("localhost","id14968057_admin","Nghi_18048881","id14968057_giohang");
  		if(!$con)
   		{
	   		die("Khong ket noi duoc den CSDL");
			exit();
		}
		else
		{			
			mysqli_set_charset($con,"utf8");
			return $con;
		}
	}

	function xuatsanpham($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close($link);
		if($i>0)
		{
			while($row= @mysqli_fetch_array($ketqua))
			{
				$id=$row['id_sanpham'];
				$ten=$row['tensanpham'];
				$gia=$row['giasanpham'];
				$gioithieu=$row['gioithieu'];
				$hinh=$row['hinhsanpham'];
				$id_loai=$row['id_loai'];
				echo'<div class="col-sm-4">
				<center>
							<div >
								<div>
									<img src="picphp/'.$hinh.'" style="height:200px;width:60%" />
									<h2>'.$gia.'VND</h2>
									<p>'.$ten.'</p>
									<a href="product-details.php?id='.$id.'" class="btn btn-default add-to-cart">More info</a>
									<a href="cart.php?id='.$id.'" class="btn btn-default add-to-cart">Add product</a>
									
									</div>
							</div>
							</center>
							
						</div>';
				
						
			}
		}
		else{
			echo 'updating data ! ';
		}
	}
	function infosanpham($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close(@link);
		if($i>0)
		{
			while($row= @mysqli_fetch_array($ketqua))
			{
				$id=$row['id_sanpham'];
				$ten=$row['tensanpham'];
				$gia=$row['giasanpham'];
				$gioithieu=$row['gioithieu'];
				$hinh=$row['hinhsanpham'];
				$id_loai=$row['id_loai'];
				echo'<div class="col-sm-3">
					'.$gioithieu.'
				</div>
				
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="picphp/'.$hinh.'" alt="" />
							</div>
							<div id="similar-product" class="carousel slide" data-ride="carousel">

								  <!-- Controls -->
								  <a class="left item-control" href="#similar-product" data-slide="prev">
									<i class="fa fa-angle-left"></i>
								  </a>
								  <a class="right item-control" href="#similar-product" data-slide="next">
									<i class="fa fa-angle-right"></i>
								  </a>
							</div>
						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<h2>'.$ten.'</h2>
								<span>
									<span>'.$gia.'.VND</span>
								</span>
								<br>
								<a href="cart.php?id='.$id.'" class="btn btn-default add-to-cart">Add Product</a>
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
				</div>';
			}
		}
		else{
			echo 'updating data ! ';
		}
	}
	function xuatmenu($sql)
	{
		$link= $this -> ketnoi();
		$ketqua = mysqli_query($link,$sql);
		$i=mysqli_num_rows($ketqua);
		@mysqli_close($link);
		if($i>0)
		{
			while($row=@mysqli_fetch_array($ketqua))
			{
				$id=$row['id_loai'];
				$name=$row['tenloaisanpham'];
				echo'<li><a class="active" href="sanpham.php?id='.$id.'"style="font-size: 20px">'.$name.'</a></li>';
			}
		}
		else
		{
			echo 'updating data';
		}
	}
	function upload($local,$name)
	{
		if($local != '' && $name !='')
		{
		    $upload_directory = __DIR__. DIRECTORY_SEPARATOR."picphp";
			$name1=$upload_directory.'/'.$name;
			if(move_uploaded_file($local,$name1))
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		
	}
	function select($sql)
		{
			$link = $this->ketnoi();
			$ketqua = mysqli_query($link,$sql);
			$i = mysqli_num_rows($ketqua);
			@mysqli_close(@link);
			if($i>0)
			{
				while($row=@mysqli_fetch_array($ketqua))
				{
					
					$id=$row['id_loai'];
					$name=$row['tenloaisanpham'];
					echo'<option value="'.$id.'">'.$name.'</option>';
				}
				
			}
			
		}

	function insert($sql){
		$link = $this -> ketnoi();
		if(mysqli_query($link,$sql))
		{
			return 1;
		}
		else{
			return 0;
		}
	}		
	function quanlydonhang($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close(@link);
		if($i>0)
		{
			while($row= @mysqli_fetch_array($ketqua))
			{
				$STT=$row['STT'];
				$id=$row['id_sanpham'];
				$ten=$row['tensanpham'];
				$gia=$row['giasanpham'];
				$hinh=$row['anhsanpham'];
				$SDT=$row['SDT_nguoimua'];
				$SL=$row['SL'];
				echo'<tr style="border:1px solid black">
							<td class="description">
								<p><center>'.$STT.'</center></p>
							</td>
							<td class="description">
								<p>'.$SDT.'</p>
							</td>
							<td class="image">
								<a href=""><center><img src="picphp/'.$hinh.'" style="width:40%"></center></a>
							</td>
							<td class="cart_description">
								<h4><a href="">'.$ten.'</a></h4>
								<p>ID: '.$id.'</p>
							</td>
							<td class="cart_price">
								<p>'.$gia.'</p>
							</td>
							<td class="cart_price">
								<p>'.$SL.'</p>
							</td>
						</tr>';
				
			}
		}
	}
	function giohang($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close(@link);
		if($i>0)
		{
			while($row= @mysqli_fetch_array($ketqua))
			{
				$id=$row['id_sanpham'];
				$ten=$row['tensanpham'];
				$gia=$row['giasanpham'];
				$hinh=$row['hinhsanpham'];
				$id_loai=$row['id_loai'];
				$STT=$row['STT'];
				$SL=$row['SL'];
				echo'<tbody>
						<form>
						<tr>
							<td class="cart_product">
								<a href=""><img src="picphp/'.$hinh.'" style="height:100px;width:100px"></a>
							</td>
							<td class="cart_description">
								<h4><a href="">'.$ten.'</a></h4>
								<p>ID:'.$id.'</p>
							</td>
							<td class="cart_price">
								<p>'.$gia.'VND</p>
							</td>
							<td class="cart_price"><br><br>
							<center><p class="cart-price">'.$SL.'</p>
								<div class="dropdown">
								  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">update</button>
								  <ul class="dropdown-menu">
									<li><a href="update.php?id='.$id.'&$SL=1" >1</a></li>
									<li><a href="update.php?id='.$id.'&$SL=2" >2</a></li>
									<li><a href="update.php?id='.$id.'&$SL=3" >3</a></li>
									<li><a href="update.php?id='.$id.'&$SL=4" >4</a></li>
									<li><a href="update.php?id='.$id.'&$SL=5" >5</a></li>
								  </ul>
								</div>	
								</center>
							</td>
							<td class="cart_price">
								<center><a href="delete.php?id='.$id.'" >xóa</a></center>
							</td>
						</tr>
						</form>
					</tbody>';
			}
		}
		else{
			echo 'updating data ! ';
		}
	}
	function donhang($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close(@link);
		if($i>0)
		{
			while($row= @mysqli_fetch_array($ketqua))
			{
				$id=$row['id_sanpham'];
				$SDT=$row['SDT_nguoimua'];
				$teansanpham=$row['tensanpham'];
				$giasanpham=$row['giasanpham'];
				$anhsanpham=$row['anhsanpham'];
				$SL=$row['SL'];
			}
		}
		else{
			echo 'updating data ! ';
		}
	}
	function khachhang($sql)
	{
		$link = $this -> ketnoi();
		$ketqua=mysqli_query($link,$sql);
		$i = mysqli_num_rows($ketqua);
		@mysqli_close(@link);
		if($i>0)
		{
		    $dem=1;
			while($row= @mysqli_fetch_array($ketqua))
			{
			    $name=$row['hovaten'];
			    $dc=$row['diachi'];
			    echo'
	                    <tr class="cart_menu"> 
						<td>Họ và tên('.$dem.')</td>
						</tr>
						<tr class="cart_menu"> 
						<td>'.$name.'</td>
						</tr>
						<tr class="cart_menu"> 
						<td>Địa Chỉ</td>
						</tr>
						<tr class="cart_menu"> 
						<td>'.$dc.'</td>
						</tr>';
						$dem++;
			}
		}
	}
}
?>