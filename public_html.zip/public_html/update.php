<?php
include("function.php");
$p=new detai();
$p->ketnoi();
session_start();
$id=$_REQUEST['id'];
$SL=$_REQUEST['$SL'];
$p->insert("UPDATE giohang SET SL=$SL where id_sanpham=$id");
header('location:cart.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>